//#include "ImageAnalyzer.hpp"
//#include "ScoreAnalyzer.hpp"
//#include "ImageObjects.hpp"
//#include "ImageGateway.hpp"
//#include<opencv2/highgui/highgui.hpp>
//#include<opencv2/core/core.hpp>
//#include<iostream>
//#include<boost/scoped_ptr.hpp>
int main(void)
{
}
